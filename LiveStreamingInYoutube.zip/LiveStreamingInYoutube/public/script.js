const userVideo = document.getElementById("user-video");
const startButton = document.getElementById("start-btn");
const chatBox = document.getElementById("chat-box");
const chatInput = document.getElementById("chat-input");
const sendButton = document.getElementById("send-btn");

const state = { media: null };
const socket = io();

window.addEventListener("load", async (e) => {
  const media = await navigator.mediaDevices.getUserMedia({
    audio: true,
    video: true,
  });
  state.media = media;
  userVideo.srcObject = media;
});

// Start streaming on button click
startButton.addEventListener("click", async (e) => {
  const mediaRecorder = new MediaRecorder(state.media, {
    audioBitsPerSecond: 128000,
    videoBitsPerSecond: 2500000,
    framerate: 25,
  });

  mediaRecorder.ondataavailable = (ev) => {
    socket.emit("binarystream", ev.data);
  };

  mediaRecorder.start(25);
});

sendButton.addEventListener("click", () => {
    const message = chatInput.value.trim();
    if (message) {
      socket.emit('chat-message', message); 
      chatInput.value = '';
    }
  });
  
  socket.on('chat-message', (message) => {
    console.log('Showing on Screen', message)
    const messageElement = document.createElement('div');
    messageElement.textContent = message;
    chatBox.appendChild(messageElement);
    chatBox.scrollTop = chatBox.scrollHeight;
  });